<?php

ini_set('error_reporting', 'E_ALL');
ini_set('display_errors', 'E_ALL');
ini_set('display_startup_errors', 'E_ALL');

require_once 'app/header.php';
?>

<div class="container">
    <?php if(isset($_GET['subscribe']) && $_GET['subscribe'] === 'exist'): ?>
    <div class="alert alert-info alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Внимание!</strong> Такой подписчик уже существует.
    </div>
    <?php endif; ?>
    <?php if(isset($_GET['subscribe']) && $_GET['subscribe'] === 'created'): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Внимание!</strong> Вы успешно подписались на обновления.
    </div>
    <?php endif; ?>
    <?php if(isset($_GET['subscribe']) && $_GET['subscribe'] === 'fail'): ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Внимание!</strong> Во время подписки произошла ошибка.
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-9">
            <div class="page-header">
                <h1>Все записи:</h1>
            </div>
            <?php
                $posts = get_posts();
            ?>
            <?php foreach($posts as $post): ?>
            <div class="row">
                <div class="col-md-3">
                    <a href="#" class="thumbnail">
                        <img src="<?=$post['image']?>" alt="">
                    </a>
                </div>
                <div class="col-md-9">
                    <h4><a href="/post.php?post_id=<?=$post['id']?>"><?=$post['title']?></a></h4>
                    <p>
                      <?=mb_substr($post['content'], 0, 128, 'UTF-8').'...'?>
                    </p>
                    <p><a class="btn btn-info btn-sm" href="/post.php?post_id=<?=$post['id']?>">Читать полностью...</a></p>
                    <br/>
                    <ul class="list-inline">
                        <li><i class="glyphicon glyphicon-list"></i> <a href="#">Категория</a> | </li>
                        <li><i class="glyphicon glyphicon-calendar"></i> 14 Мая 2017 21:00
                    </ul>
                </div>
            </div>
            <hr>
            <?php endforeach; ?>
        </div>
        <div class="col-md-3">
            <?php include_once 'app/sidebar.php'; ?>
        </div>
    </div>
</div>

<?php

include_once 'app/footer.php';

?>