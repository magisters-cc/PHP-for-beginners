﻿<div class="well">
    <div class="form-group">
        <form action="/subscribe.php" method="post">
            <h4>Подпишись на новости!</h4>
            <br>
            <input type="email" id="subscribe-email" name="email" value="" class="form-control" placeholder="Введите Ваш email" required>
            <br>
            <button type="submit" id="subscribe-submit" class="btn btn-success">Подписаться</button>
        </form>
    </div>
</div>

<script>

    var input = document.getElementById('subscribe-email');
    
    var button = document.getElementById('subscribe-submit');
    button.style.display = 'none';
   
    input.addEventListener('input', function (event) {
        var email = event.target.value;

        if (validateEmail(email)) {
            //1 
            button.style.display = 'inline-block';
        } else {
            //2
            button.style.display = 'none';
        }
    });
   
    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email.toLowerCase());
    }

</script>